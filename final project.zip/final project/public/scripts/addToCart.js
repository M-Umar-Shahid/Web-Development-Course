$(document).ready(function () {
  const quantityInput = $(".quantity-input");
  const decreaseButton = $("[data-action='decrease']");
  const increaseButton = $("[data-action='increase']");
  decreaseButton.click(function () {
    if (parseInt(quantityInput.val()) > 1) {
      quantityInput.val(parseInt(quantityInput.val()) - 1);
    }
  });

  increaseButton.click(function () {
    quantityInput.val(parseInt(quantityInput.val()) + 1);
  });
});
