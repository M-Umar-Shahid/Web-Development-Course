$(document).ready(function () {
  $(".add-to-cart").on("click", function () {
    // Access data attributes
    var perfumeId = $(this).data("id");
    var perfumeName = $(this).data("name");
    var perfumePrice = $(this).data("price");
    var quantity = $(this)
      .siblings(".input-group")
      .find(".quantity-input")
      .val();

    var cartItem = `
      <li class="cart-item" data-id="${perfumeId}">
        <p>Name: ${perfumeName}</p>
        <p>Price: $${perfumePrice}</p>
        <p>Quantity: ${quantity}</p>
      </li>
    `;

    var cartItems = [];
    // var cartItemgotpage = [];
    cartItems.push(cartItem);
    // cartItemgotpage.push(cartItem);
    // console.log("data in cart is ", cartItemgotpage);
    // console.log("data in cartItems is ", cartItems);

    // Append the new cart item to the cart items list
    $("#cart-items").append(cartItems);
    cartItems = [];

    // Optionally, you can show the sidebar if it's hidden
    // $('#sidebar').show();
    openSidebar(); // If you have a function to open the sidebar
  });
});
